ASISTENSIA - LOGO PACK
======================

FOLDERS
SVG     Vector master files (text converted to outlines - no font needed). Use for web and for designers.
PDF     Vector files for print shops, documents and presentations.
EPS     Vector files for older design software, sign makers and embroidery.
PNG     Raster images, transparent background (plus white/navy background versions).
JPG     Raster images on a solid background, for places that do not accept transparency.
Favicon Website icons: favicon.ico, favicon.svg, 16/32/48 px, Apple touch icon, Android icons.

VERSIONS
logo-primary         Navy circle + navy wordmark. Use on white or light backgrounds.
logo-reversed        White circle + white wordmark. Use on navy or dark backgrounds.
logo-navy-onecolor   Single navy colour (the "a" is cut out of the circle).
logo-black           Single black colour, for black-and-white printing, stamps, fax.
logo-white           Single white colour, for photos and dark backgrounds.
icon-*               The circle "a" alone: app icons, social profile pictures, favicon.

COLOURS
Navy   HEX #1B2A4A   RGB 27 42 74    CMYK approx. 64 43 0 71
White  HEX #FFFFFF   RGB 255 255 255
(Slate #64748B / RGB 100 116 139 is the secondary brand colour.)

TYPEFACE
Wordmark: Outfit Medium (Google Fonts, SIL Open Font License).

USAGE
- Keep clear space around the logo of at least one quarter of the circle's width.
- Do not stretch, recolour, rotate or add shadows/effects.
- Minimum size: full logo 100 px / 25 mm wide; icon 16 px / 6 mm.
